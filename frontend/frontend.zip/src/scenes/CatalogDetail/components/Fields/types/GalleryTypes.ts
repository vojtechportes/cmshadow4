export const GalleryTypes = {
  GALLERY_IMAGE: 'galleryImage'
}