export const getFieldName = (name: string): string => {
  return name.replace('[value]', '')
}
