import React from 'react'
import { RouteComponentProps } from '@reach/router'

export const Settings: React.FC<RouteComponentProps> = () => (
  <>Settings</>
)