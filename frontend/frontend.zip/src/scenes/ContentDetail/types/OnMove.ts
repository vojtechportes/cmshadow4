export type OnMove = (
  slotId: number,
  dragIndex: number,
  hoverIndex: number
) => void
