export const ItemTypes = {
  NEW_MODULE: 'new_module',
  MODULE: 'module',
}
