import React from 'react'
import { RouteComponentProps } from '@reach/router'

export const Dashboard: React.FC<RouteComponentProps> = () => (
  <>Dashboard</>
)