import React from 'react'
import { RouteComponentProps } from '@reach/router'

export const Forms: React.FC<RouteComponentProps> = () => (
  <>Forms</>
)