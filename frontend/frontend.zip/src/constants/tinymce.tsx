export const TINYMCE_SCRIPT_PATH = `${process.env.PUBLIC_URL}/js/tinymce/tinymce.min.js`
