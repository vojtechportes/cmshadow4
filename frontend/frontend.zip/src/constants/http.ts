export const ACCEPT_LANGUAGE_HEADER = 'Accept-Language'
export const AUTHORIZATION_HEADER = 'Authorization'
export const ACCEPT = 'Accept'
