import React, { useCallback } from 'react'
import { Editor, IAllProps } from '@tinymce/tinymce-react'
import { useFormikContext, useField } from 'formik'
import { TINYMCE_SCRIPT_PATH } from 'constants/tinymce'

const { CMS_BASE_URL } = window._envConfig

export const initValues: Record<string, any> = {
  height: 350,
  toolbar: `undo redo | formatselect | image 
   | bold italic backcolor | alignleft aligncenter 
   alignright alignjustify | bullist numlist outdent indent | removeformat `,
  plugins: [
    'image imagetools',
    'lists link',
    'searchreplace visualblocks code fullscreen',
    'insertdatetime media table paste code help wordcount',
  ],
  images_upload_url: CMS_BASE_URL + '/filemanager',
  entity_encoding: 'raw',
  paste_as_text: true
}

export interface RichTextFormikProps extends IAllProps {
  name: string
}

export const RichTextFormik: React.FC<RichTextFormikProps> = ({
  name,
  ...props
}) => {
  const { setFieldValue, setFieldTouched } = useFormikContext()
  const [field] = useField(name)

  const handleEditorChange = useCallback(
    (content: string) => {
      setFieldValue(name, content)
      setFieldTouched(name, true)
    },
    [setFieldValue, setFieldTouched, name]
  )

  return (
    <Editor
      initialValue={field.value}
      onEditorChange={handleEditorChange}
      tinymceScriptSrc={TINYMCE_SCRIPT_PATH}
      init={initValues}
      {...props}
    />
  )
}
