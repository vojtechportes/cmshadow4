import { createGlobalStyle } from 'styled-components'
import 'antd/dist/antd.css'

const GlobalStyle = createGlobalStyle``

export default GlobalStyle
