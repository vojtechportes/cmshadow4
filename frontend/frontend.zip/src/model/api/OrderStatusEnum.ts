export enum OrderStatusEnum {
  'NEW' = 'NEW',
  'ACCEPTED' = 'ACCEPTED',
  'REJECTED' = 'REJECTED',
  'CLOSED' = 'CLOSED',
}
