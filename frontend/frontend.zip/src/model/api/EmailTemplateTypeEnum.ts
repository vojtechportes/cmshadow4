export enum EmailTemplateTypeEnum {
  ORDER_NEW,
  ORDER_ACCEPTED,
  ORDER_REJECTED,
  ORDER_CLOSED,
}
