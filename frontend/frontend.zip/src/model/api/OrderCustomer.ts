export interface OrderCustomer {
  [key: string]: string
}