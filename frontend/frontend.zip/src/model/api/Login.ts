export interface Login {
  access_token: string
  token_type: string
  expires_in: number
  expiration_time: number
}
