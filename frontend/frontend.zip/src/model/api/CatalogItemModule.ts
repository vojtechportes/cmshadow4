export interface CatalogItemModule {
  parent_id: number
  catalog_item_id: number
  language_code: string | null
  sort: string | null
}
