export interface CatalogSearchModule {
  parent_id: number
  search_placeholder: string
  submit_label: string
}
