export interface ImageModule {
  parent_id: number
  file_name: string
  image_alt: string
}
