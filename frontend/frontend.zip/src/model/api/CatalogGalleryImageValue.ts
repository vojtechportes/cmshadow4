export interface CatalogGalleryImageValues {
  image: string
  thumbnail: string
  title: string
  description: string
}