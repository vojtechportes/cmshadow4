export interface NavigationModule {
  parent_id: number
  navigation_id: number
}