export interface TemplatePreview {
  properties: {
    [name: string]: {
      type: string
    }
  },
  template: string
}