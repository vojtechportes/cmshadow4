export interface Navigation {
  id: number
  name: string
  path: string
}