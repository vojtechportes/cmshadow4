export interface CatalogCetgoryDetailData {
  name: string
  description: string
}