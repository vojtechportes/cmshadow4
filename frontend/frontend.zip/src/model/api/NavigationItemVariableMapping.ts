export interface NavigationItemVariableMapping {
  id: number
  navigation_id: number
  navigation_item_id: number
  variable_name: string
  value: string
}
