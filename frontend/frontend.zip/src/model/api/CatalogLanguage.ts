export interface CatalogLanguage {
  name: string
  code: string
  default_currency_id: number | null
  default_tax_rate_id: number | null
}