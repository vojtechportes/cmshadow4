export enum PageStatusEnum {
  'DRAFT' = 'DRAFT',
  'PUBLISHED' = 'PUBLISHED',
  'UNPUBLISHED' = 'UNPUBLISHED',
  'DELETED' = 'DELETED',
}
