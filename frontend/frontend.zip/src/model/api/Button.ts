export interface Button {
  id: number
  name: string
  class_name: string
}
