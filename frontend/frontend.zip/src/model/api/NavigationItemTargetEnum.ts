export enum NavigationItemTargetEnum {
  'BLANK' = 'BLANK',
  'SELF' = 'SELF',
  'TOP' = 'TOP',
  'PARENT' = 'PARENT',
}
