export enum ButtonModuleTargetEnum {
  'BLANK' = 'BLANK',
  'SELF' = 'SELF',
  'TOP' = 'TOP',
  'PARENT' = 'PARENT',
}
