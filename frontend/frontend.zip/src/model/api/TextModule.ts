export interface TextModule {
  parent_id: number
  content: string
}