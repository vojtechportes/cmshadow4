export interface CatalogItemTemplate {
  id: number
  view_id: number
  name: string
  path: string
}