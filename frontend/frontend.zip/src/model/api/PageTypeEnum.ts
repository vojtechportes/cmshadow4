export enum PageTypeEnum {
  'PAGE' = 'PAGE',
  'TEMPLATE_PAGE' = 'TEMPLATE_PAGE',
}
