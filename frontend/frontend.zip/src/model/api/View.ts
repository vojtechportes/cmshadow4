export interface View {
  id: number
  name: string
  path: string
}