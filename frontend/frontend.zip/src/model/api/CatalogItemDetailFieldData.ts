export interface CatalogItemFieldData {
  id: number
  item_id: number
  field_id: number
  language: string | null
  value: any
  extra_content: any
}