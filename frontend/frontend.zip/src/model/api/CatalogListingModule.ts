export interface CatalogListingModule {
  parent_id: number
  language_code: string | null
  category_id: number | null
  category_id_variable_name: string | null
}