import { LayoutSlot } from './LayoutSlot'

export type LayoutSlotDetail = Omit<LayoutSlot, 'children'>