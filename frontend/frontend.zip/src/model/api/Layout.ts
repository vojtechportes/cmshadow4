export interface Layout {
  id: number
  name: string
  created_at: Date
  created_by: number
  modified_at: Date
  modified_by: number
}
