export interface CatalogCurrencyTaxRate {
  id: number
  currency_id: number
  rate: number | null
  weight: number
}