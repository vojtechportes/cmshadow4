// tslint:disable
declare module "react-jsx-parser";