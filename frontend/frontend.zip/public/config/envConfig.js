/**
 * Development defaults that should be overridden
 */
window._envConfig = {
  GA_TRACKING_CODE: 'UA-158896638-1',
  CMS_BASE_URL: '/api/v1',
  CMS_STATIC_URL: '/storage/user'
}
